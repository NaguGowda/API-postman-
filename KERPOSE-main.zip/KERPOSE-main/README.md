# KERPOSE
This is website for vehicle and insurance management. 
https://kerbos.azurewebsites.net/
I handled API response and Data Mapping, Request and response of server through API in manually within POSTMAN.

This was a demo website that have less future or restricted features.
Tested here the main productivity component of web application.
